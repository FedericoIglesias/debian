shutdown now
ip address
ping 8.8.8.8
ip a
shutdown now
ls
ls -la
touch entre.txt
l
ls
ping 8.8.8.8
ls
cd ..
ls
apt-cache apache2
apt cache apache2
exit
cd ..
cd etc/ssh/
ls
vim sshd_config
ls
cd ..
c.
cd ..
ls
cd home/compartido/
ls
ls -a
cd .ssh
ls
mv clave_publica.pub /etc/ssh/
ls
cd ..
cd ..
cd ..
ls
cd etc/ssh/
ls
cd ..
cd ..
ls
cd ro
cd root/
ls
ls -a
cd .ssh/
ls
cat clave_publica.pub 
cd config
cat config 
ping 8.8.8.8
ls -la
touch authorized_key
ls
cat clave_publica.pub >> authorized_key 
cat authorized_key 
cat clave_publica.pub 
chmod 600 authorized_key 
ls -la
cd ..
cd ..
ls
cd etc/ssh/
ls
sshd_config.d/
vim sshd_config
systemctl restart
systemctl restart ssh
ip a
cd ..
cd ..
cd r
cd root/
ñs
ls -a
chmod 700 .ssh/
ls -la
ls .ssh/
cd .ssh/
mv authorized_key authorized_keys
clear
ls
systemctl restart ssh
ls -la
cd ..
ls
rm entre.txt 
apt update && apt upgrade && apt install apache2
shutdown now
ls
cd ..
ls
systemctl status apache2
clear
apt install php libapache2-mod-php
php -v
clear
php -v
systemctl restart apache2
ls
cd ..
ls
cd dev/
ls
cd www
cd ..
cd var/
ls
cd www/
ls
ls -la
cd html/
ls
cat index.html 
a2enmod mime
cd ..c
cd --
cd ..
cd home/
ls
cd compartido/
ls
cd myFolder/
ls
cp -r myFolder /var/www
cp -r myFolder /var/www
cp myFolder /var/www
ls
cp index.php /var/www/html/
ls
ls
cd ..
cd ..
cd .
cd ..
ls
cd var/
cd www/html/
ls
ip a
ls
systemctl restart apache2
cat index.php 
cd --
cd .
cd ..
apt install mariadb-server
systemctl enable mariadb
systemctl start mariadb
find / -iname mariadb
mariadb
ls
cd home/compartido/myFolder/
ls
mysql -u root -p mydatabase < db.sql 
mysql -u root -p mydatabase < db.sql 
mysql
mysql -u root -p ingenieria < db.sql 
mariadb
mysql -u root -p ingenieria < db.sql 
mariadb 
mysql < db.sql 
clear
mysql -u root -p < db.sql 
mysql -u root -p
mysql -u root -p < db.sql 
ls
cp db.sql db1.sql
vim db1.sql 
mysql < db1.sql 
vim db1.sql 
mysql < db1.sql 
mysql < db1.sql 
shutdown -h
shutdown now
lsblk
fdisk
ls
cd ..
ls
cd  dev/
ls
cd sdc
cd disk/
ls
cd ..
ls -la 
clear
ls
cd ..
lslbk
lsblk
fdisk dev/sdc 
fdisk dev/sdc 
lsblk
ls
mkdir www_dir
mkdir backup_dir
mount dev/sdc1 
mkfs -t ext4 dev/sdc1
mkfs -t ext4 dev/sdc2
mount dev/sdc1 /www_dir
mount dev/sdc2 /backup_dir
lsblk
cp home/compartido/myFolder/index.php /www_dir/
ls www_dir/
ls -la www_dir/
ds -h
df -h
lsblk
cd etc
ls
vim fstab 
lsblk
cat fstab 
mount -a
clear
cd ..
find / -iname 000-default.conf
cd etc/apache2/sites-available/000-default.conf
cd etc/apache2/sites-available/
ñs
ls
vim 000-default.conf 
cd ..
cd sites-enabled/
ls
vim 000-default.conf 
cd etc/apache2/sites-available/
cd /etc/apache2/sites-available/
ls
vim 000-default.conf 
clear
ls
cd ..
ls
cd --
cd --
cd ..
clear
shutdown now
systemctl start apache2
systemctl enbale apache2
systemctl enable apache2
ls
cd ..
systemctl status apache2
ls
cd www_dir/
ls
cat index.php 
cd ..
cd etc/apache2/
ls
ls -la
vim apache2.conf 
clear
ls
ls -l
cd sites-
cd sites-available/
ñs
ls
vim 000-default.conf 
ls
cd ..
ls
cd sites-enabled/
ls
vim 000-default.conf 
ls
cd ..
ls -l
ls -la
ls mods-available/
a2enmod mime
systemctl restart apache2
ip a
cd --
c d..
cd ..
ls
clear
chown -R www-data:www-data /www_dir/
chmod -R 755 www_dir/
systemctl restart apache2
lsblk
lsblk
df -h
shutdown -r now
cd ..
ls
ls www_dir/
vim /dev/fdtab
ls dev
vim etc/fstab 
shutdown -r now
clear
cd ..
systemctl start apache2
systemctl enable apache2
cd etc/
ls
vim passwd
cd ..
chown www-data:www-data /www_dir/
chmod -R 755 www_dir/
cd www_dir/
ls -l
ls -la /www_dir
cd ..
vim /etc/apache2/sites-available/000-default.conf 
clear
vim etc/apache2/apache2.conf 
cd ..
systemctl restart apache2
man tee
EHCO "HI" > /www_dir/index.html
ECHO "HI" > /www_dir/index.html
echo "HI" > /www_dir/index.html
ls
cd www_dir/
ls
systemctl status mariadb
vim index.php 
vim index.php 
vim index.php 
ls
shutdown -r now
systemctl status apache2
vim /www_dir/
vim /www_dir/index.php 
cd ..
etc
cd etc/
ls
systemctl status mysql
cd ..
ls
cd run/
ls
cd mysqld/
ls
man tail
clear
ls
cat mysqld.sock 
ls -l
cat mysqld.pid 
cd ...
cd ..
cd ..
vim /etc/mysql/mariadb.conf.d/50-server.cnf 
vim /www_dir/index.php 
cd ..
ls
ls proc/
cat proc/partitions 
c d..
cd ..
ls
ufw allow 33036/tcp
clear
lsblk
fdisk
fdisk /dev/sdc1
lsblk
fdisk dev/sdc
unmount dev/sdc1
umount /dev/sdc1
umount /dev/sdc2
fdisk /dev/sdc
ls
cat /proc/partitions 
lsblk
shutdown now
cd ,,
cd ..
vim /etc/fstab 
shutdown -r now
lsblk
fdisk
fdisk dev/sdc
clear
lsblk
fdisk /dev/sdc
lsblk
fdisk -t ext4 /dev/sdc1
mkfs -t ext4 /dev/sdc1
mkfs -t ext4 /dev/sdc2
fs -h
fd -h
fl -h
fd
ds -h
df -h
cd ..
clear
mount /dev/sdc1 /backup_dir
mount /dev/sdc2 /www_dir/
ls
ds -h
df -h
lsblk
vim etc/fstab 
cat /proc/partitions > /proc/log_partition
cat proc/partitions >> /proc/log_partition
tocuh /proc/partition
touch /proc/partition 
ls
cd proc/
cat partitions > partition
cat partitions >> partition
cat partitions 
touch partition
touch partition.txt
vim partition
touch man
man touch
touch texto.txt
touch 
touch cat partitions 
cat partitions 
cp partitions /
cd ..
ls
mv partitions partition
ls
mv partition /proc/
ls -l
chmod -R 755 /proc
ls -l
ls
rm partition 
cat /proc/partitions > /proc/particion
cat /proc/partitions >> /proc/particion
touch particio
cat /proc/partitions >> /particion
cat particion
mv particion /proc
ls -s 
ls -help
ls --help
clear
ls
mv particion home/compartido/
ls
shutdown -r
shutdown -r now
vim /etc/fstab 
shutdown -r now
cd ..
systemctl status apache2
clear
cd /etc/apache2/
ls
vim apache2.conf 
ls
cat sites-available/
cat sites-available/000-default.conf 
cd mm
cd /
ls www_dir/
ls
cd home/compartido/myFolder/
ls
cp index.php /www_dir/
clear
systemctl status mariadb
cd /
vim www_dir/index.php 
mysql
Q
clear
cd opt/
ls
mkdir script
cd script/
cd ..
mv script scripts
ls
cd scripts/
touch backup_full.sh
vim backup_full.sh 
ls
shutdown now
ps
ps aux
ps aux
clear
cd ..
ps 
ps aux -u root
ps -ef
clear
shutdowm
shutdown
shutdown now
exit 

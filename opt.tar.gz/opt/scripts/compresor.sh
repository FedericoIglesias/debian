tar -cvzf /compress/etc.tar.gz /etc
tar -cvzf /compress/root.tar.gz /root
tar -cvzf /compress/opt.tar.gz /opt
tar -cvzf /compress/var.tar.gz /var
tar -cvzf /compress/www_dir.tar.gz /www_dir
tar -cvzf /compress/backup_dir.tar.gz /backup_dir
split -b 90M /compress/var.tar.gz /compress/var.tar.gz_
rm /compress/var.tar.gz

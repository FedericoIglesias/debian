
DATE=$(date +%Y%m%d)
SCRIPT_NAME=$(basename $0)

if [[ $1 == "-help" ]]; then
	echo "$SCRIPT_NAME <directorio origen> <directorio destino>"
	exit 0
fi

if [[ ! -d $1 ]]; then
	echo "El directorio de origen es incorrecto"
	exit 0
fi

if [[ ! -d $2 ]]; then
	echo "el directorio de destino es incorrecto"
	exit 0
fi

ORIGIN=$1
DEST=$2
NAME=$(basename $ORIGIN)
BACKUP_NAME="${DEST}/${NAME}_bkp_${DATE}.tar.gz"


tar -cvzf $BACKUP_NAME $ORIGIN
